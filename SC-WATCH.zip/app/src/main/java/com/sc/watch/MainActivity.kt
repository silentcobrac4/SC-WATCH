package com.sc.watch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SCWatchApp()
        }
    }
}

@Composable
fun SCWatchApp() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0A0A0C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(id = R.string.app_name),
                color = Color(0xFF00E5A3),
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = stringResource(id = R.string.title_dashboard),
                color = Color.White,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = { /* Implement Wi-Fi Scan */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5A3))
            ) {
                Text(text = stringResource(id = R.string.wifi_scans), color = Color.Black)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = { /* Implement BLE Scan */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16181D))
            ) {
                Text(text = stringResource(id = R.string.ble_scans), color = Color.White)
            }
        }
    }
}
